function [impo1]=brute_force()
r1=0;
r2=1;
load('output_signal_two_three.mat');
key1=output_signal_two_three;
impo1=[];
sequence=[];
for i = 1:72
    similiraty=[];
    template1=key1(i,:);
    for j=1:1000
     rng(j)
     template2=double(rand(1,1536)>0.5);
     C2=template_match1(template1,template2);
     similiraty=[similiraty,C2];
    end
     impo1 = [impo1; max(similiraty)];
 end
end