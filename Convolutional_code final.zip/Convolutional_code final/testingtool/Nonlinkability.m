clc;
[gen,seq]=pseudo_genuinue();
 [impo,seq1]=pseudo_imposter(); 

 [muhat,sigma] = normfit(gen);
  % construct histogram
[F,X] = hist(gen,80);
% get ready to plot as probability histogram
F = F/trapz(X,F);
%bar(X,F); hold on;
% use muhat and sigma to construct pdf
x = muhat-3*sigma:0.01:muhat+3*sigma;
% plot PDF over histogram
y = normpdf(x,muhat,sigma);
%yyaxis left
plot(x,y,'r-^','linewidth',2);
hold on;
[muhat1,sigma1] = normfit(impo);
% construct histogram
[F1,X1] = hist(impo,80);
% get ready to plot as probability histogram
F1 = F1/trapz(X1,F1);
%bar(X1,F1); hold on;
% use muhat and sigma to construct pdf
x1 = muhat1-3*sigma1:0.01:muhat1+3*sigma1;
% plot PDF over histogram
y1 = normpdf(x1,muhat1,sigma1);
%yyaxis left
plot(x1,y1,'b-*','linewidth',2);
hold on;


%plotyy(x,y,x1,y1,'plot');
%plotyy(x2,y2,x11,y11,'plot');
xlabel('Matching score');
ylabel('Frequency');
legend1 = sprintf('Psuedo-genuine(mean = %.01f)', mean(gen));
legend2 = sprintf('Pseudo-imposter(mean = %.3f)', mean(impo));
legend({legend1, legend2});