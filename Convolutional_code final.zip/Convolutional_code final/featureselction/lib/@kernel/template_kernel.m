function K = YOUR_KERNEL(kern,d1,d2,ind1,ind2,kerparam),

% Define your kernel like this function, just replace YOUR_KERNEL
%   and define the function below, between matrices
%   get_x(d2,ind2) and get_x(d1,ind1), e.g K = get_x(d2,ind2)*get_x(d1,ind1)';
%   for a linear kernel.
  