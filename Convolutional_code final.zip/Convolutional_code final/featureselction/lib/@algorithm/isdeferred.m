function y = isdeferred(a)

y = isa(a.deferred, 'ssj');
