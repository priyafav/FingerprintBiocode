rank=load('rankingfull6.mat');
result_wt=rank.test;
load('projected_feature_6.mat');
[O_min,O_mid_1,O_mean,O_mid_2]=Qunatisation_parameter_full(result_wt,projected_feature1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
result_dt_one=[];
result_dt_one=one_bitquantisation(projected_feature1,result_wt,O_mean);
resl_rt_one=[];
for i=1:72
    for j=1:72
        resl_rt_one(i,j)=sum(result_dt_one(i,:)==result_dt_one(j,:))/512;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%two-bit quantisation
result_quant=[];
result_quant=two_bitquantisation(projected_feature1,result_wt,O_min,O_mid_1,O_mean,O_mid_2);

resl_rt_two=[];
for i=1:72
    for j=1:72
        resl_rt_two(i,j)=sum(result_quant(i,:)==result_quant(j,:))/1024;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 
%Convolutional_code 1-bit quantisation
%% 
h=result_dt_one;
trellis = poly2trellis(7,{'1 + x^3 + x^4 + x^5 + x^6', ...
    '1 + x + x^3 + x^4 + x^6'});
output_signal_punctured=[];
output_signal_two_three=[];
output_signal_one_two=[];
for i=1:72
output_signal_punctured = [output_signal_punctured;(convenc(h(i,:),trellis,[1 1 1 0 1 0 1 1]))];
output_signal_two_three = [output_signal_two_three;(convenc(h(i,:),poly2trellis([5 4],[23 35 0; 0 5 13])))];
output_signal_one_two=[output_signal_one_two;convenc(h(i,:),trellis)];
end
%%%%%%%%%%%%%%%%%%%
result_signalpunctured=[];
for i=1:72
    for j=1:72
        result_signalpunctured(i,j)=sum(output_signal_punctured(i,:)==output_signal_punctured(j,:))/1536;
    end
end
%% 
%%%%%
%% 
result_signaltwothree=[];
for i=1:72
    for j=1:72
        result_signaltwothree(i,j)=sum(output_signal_two_three(i,:)==output_signal_two_three(j,:))/1536;
    end
end

%%%%%%%%%%%%%%%%%
result_signalcode=[];
for i=1:72
    for j=1:72
        result_signalcode(i,j)=sum(output_signal_one_two(i,:)==output_signal_one_two(j,:))/2048;
    end
end

