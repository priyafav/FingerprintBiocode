function [O_min,O_mid_1,O_mean,O_mid_2]=Qunatisation_parameter_part(result_wt,projected_feature1)
final_dist1=[];
for j=1:9
    t=[];
    for k=1:2:8
      t=projected_feature1{1,j}';
      final_dist1=[final_dist1;t(k,:).*result_wt(j,:)];
    end
    
end

dist_mean=mean(abs(final_dist1),2);
dist_max=max(abs(final_dist1),[],2);
dist_min=min(abs(final_dist1),[],2);
s=1;
for l=1:4:36
    overall_mean(s)=mean(dist_mean(l:l+3));
    s=s+1;
end

t=1;
for l=1:4:36
    overall_max(t)=max(dist_max(l:l+3));
    overall_min(t)=min(dist_min(l:l+3));
    mid_1(t)=(overall_mean(t)-overall_min(t))/2;
    
    mid_2(t)=(overall_max(t)-overall_mean(t))/2;
    t=t+1;
end
O_mean=mean(overall_mean);
O_mid_1=mean(mid_1);
O_mid_2=mean(mid_2);
O_min=mean(overall_min);
end
