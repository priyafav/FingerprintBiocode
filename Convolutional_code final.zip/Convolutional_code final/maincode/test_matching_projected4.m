p=load('projected_feature_4.mat');
result_vector=[];
for i=1:9
   result_vector=[result_vector;projected_feature1{1,i}'];
 end
for i=1:72
    for j=1:72
        dist_matrix(i,j)=1-norm(result_vector(i,:)-result_vector(j,:))/(norm(result_vector(i,:))+(norm(result_vector(j,:))));
    end
end