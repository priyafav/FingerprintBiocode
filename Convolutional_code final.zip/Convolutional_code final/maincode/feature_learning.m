s=load('FVC2002_DB1result.mat');
binary_code=[];
projected_feature1=[];
feature1=[];
for k=1:9
    for l=1:8
        feature1{k,l}=rad2deg(s.feature_vector2update{k,l});
    end
end

fet=[];
feat=[];
for i=1:9 %1,3,5,7
    fet(:,1:8)=[feature1{i,1}',feature1{i,3}',feature1{i,5}',feature1{i,7}',feature1{i,2}',feature1{i,4}',feature1{i,6}',feature1{i,8}'];
    feat(:,1)=(fet(:,1)-mean(mean(fet,2)));
   feat(:,2)=(fet(:,2)-mean(mean(fet,2)));
    feat(:,3)=(fet(:,3)-mean(mean(fet,2)));
    feat(:,4)=(fet(:,4)-mean(mean(fet,2)));
%      feat(:,5)=(fet(:,5)-mean(mean(fet,2)));
%    feat(:,6)=(fet(:,6)-mean(mean(fet,2)));
%    feat(:,7)=(fet(:,7)-mean(mean(fet,2)));
%     feat(:,8)=(fet(:,8)-mean(mean(fet,2)));
    
    weight_matrix1=cov(feat');
    %weight_matrix1=feat*feat';
    [V,D] =eigs(weight_matrix1',637);
    [d,ind] = sort(diag(D),'descend');
    d1=abs(d)<=10^2;
    d3{i}=d1;
    ind1=ind(d1);
     %d1=d;
    Ds = D(ind1,ind1);
    Vs = V(:,ind1);
    model.vs{i}=Vs';

end
for i=1:9
  for k=1:8
      q=0;
    projected_feature1{i}(:,k)=model.vs{i}*feature1{i,k}';
    q=projected_feature1{i}(:,k);
    save([num2str(i) '_' num2str(k) '.mat'],'q');
  end
end

save('projected_feature_4.mat','projected_feature1');
