function result_dt=one_bitquantisation4(projected_feature1,result_wt,O_mean)
  [~,index]=sort(result_wt(1,:));
    final_dist=[];
    for i=1:9
        final_dist=[final_dist;projected_feature1{1,i}'];
    end
    result_dt=[];
    k=1;
    for i=1:8:72
        result_dt(i:i+7,:)=abs(final_dist(i:i+7,index(123:end)))>O_mean;
        k=k+1;
    end
end