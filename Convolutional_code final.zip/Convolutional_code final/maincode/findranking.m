function weight=findranking(w)
s=length(w);
weight=[];
for i=1:s
    a=find(w==i);
  weight(i)=1-a*(1/s);  
end
end