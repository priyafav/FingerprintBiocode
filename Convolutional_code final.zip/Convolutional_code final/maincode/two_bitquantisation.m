function result_quant=two_bitquantisation(projected_feature1,result_wt,O_min,O_mid_1,O_mean,O_mid_2)
       [~,index]=sort(result_wt(1,:));
        final_dist=[];
        for i=1:9
            final_dist=[final_dist;projected_feature1{1,i}'];
        end

    result_quant=[];
    k=1;
    for i=1:8:72
       for j=1:8
         result_quant(i+(j-1),:)=quantisation(abs(final_dist(i+(j-1),index(120:end))),O_min,O_mid_1,O_mean,O_mid_2);
       end
        k=k+1;
    end
end



function result=quantisation(arr,mn,mid1,mean1,mid2)
result=[];
for i=1:512
    x=[];
    x=arr(1,i);
    if(mn<=x & x <= mid1)
        val=[0,0];
    elseif(mid1< x & x <= mean1)
        val=[0,1];
    elseif(mean1< x & x <= mid2)
        val=[1,0];
    else
        val=[1,1];
    end
    result=[result,val];
end
end