% FEATURE SELECTION TOOLBOX v 6.2 2018 - For Matlab 
% Please, select a feature selection method from the list:
% [1] ILFS 
%% DEMO FILE
clear all
close all
clc;
% Include dependencies
addpath('./lib'); % dependencies
addpath('./methods'); % FS methods
addpath(genpath('./lib/drtoolbox'));

listFS = {'ILFS'};

[ methodID ] = readInput( listFS );
selection_method = listFS{methodID}; % Selected
%load data
load('projected_feature_6.mat');
final_dist=[];
for i=1:9
    final_dist=[final_dist;projected_feature1{1,i}'];
end

rankings=[];
accuracy=[];
 X=final_dist;
Y(1:8)=1;
 Y(9:16)=1;
 Y(17:24)=1;
 Y(25:32)=1;
 Y(33:40)=1;
 Y(41:48)=1;
 Y(49:56)=1;
 Y(57:64)=1;
 Y(65:72)=-1;
 
 Y=Y';
% Randomly partitions observations into a training set and a test
% set using stratified holdout
P = cvpartition(Y,'Holdout',0.40);

X_train = double( X(P.training,:) );
Y_train = (double( Y(P.training))); % labels: neg_class -1, pos_class +1
X_train = [X_train];
X_test = double( X(P.test,:) );
Y_test = (double( Y(P.test) )); % labels: neg_class -1, pos_class +1
X_test = [X_test];

numF = size(X_train,2);


% feature Selection on training data
switch lower(selection_method)
     
    case 'ilfs'
        % Infinite Latent Feature Selection - ICCV 2017
        [ranking, w] = ILFS(X_train, Y_train , 6, 0 );
        
    otherwise
        disp('Unknown method.')
end

k = 631; % select the first 2 features

% Use a linear support vector machine classifier
svmStruct = fitcsvm(X_train(:,ranking(1:k)),Y_train);
C = predict(svmStruct,X_test(:,ranking(1:k)));
err_rate = sum(Y_test~= C)/P.TestSize; % mis-classification rate
conMat = confusionmat(Y_test,C); % the confusion matrix

disp('X_train size')
size(X_train)

disp('Y_train size')
size(Y_train)

disp('X_test size')
size(X_test)

disp('Y_test size')
size(Y_test)

save('ilfsw_19.mat','w');
save('ilfsr_19.mat','ranking');
fprintf('\nMethod %s (Linear-SVMs): Accuracy: %.2f%%, Error-Rate: %.2f \n',selection_method,100*(1-err_rate),err_rate);


X_t=X(:,sort(ranking));
result_vector=X_t(:,1:512);
for i=1:72
    for j=1:72
    dist_matrix(i,j)=1-norm(result_vector(i,:)-result_vector(j,:))/(norm(result_vector(i,:))+(norm(result_vector(j,:))));
    end
end

