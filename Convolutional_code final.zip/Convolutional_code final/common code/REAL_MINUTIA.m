%MINUTIA EXTRACTION FROM REAL IMAGE
real_minutia=[];
for i=1:5
    for j=1:8
     im=imread(['10' num2str(i)  '_' num2str(j) '.jpg']);
     im1=imresize(im,[280 280]);
     ret= ext_finger(double(im1));
     blksze = 16; thresh = 0.3;
     [normim, mask] = ridgesegment(im, blksze, thresh);
     mask(floor(size(mask,1)/blksze)*blksze+1:size(mask,1),:)=0;
     mask(:,floor(size(mask,2)/blksze)*blksze+1:size(mask,2))=0;
     mask = imopen(mask, strel('square',2*blksze));
     % 3.2 orientation field estimation
     orientim = ridgeorient(normim, 1, 3,3);
     orientim  = pi - orientim;
     % 3.3 detect singular points by giving step lenth and number of starting
     % points
     detectedsp3 = walking(im, mask, orientim, 7, 2);
     detectedsp = detectedsp3;
     real_minutia{i,j}=ret;
     if(detectedsp.core~=0)
       real_minutia{i,j}(end+1,1:2)=detectedsp.core(1,:);
       real_minutia{i,j}(end+1,3:6)=[0,0,0,0];
     else
       real_minutia{i,j}(end+1,1:6)=[0,0,0,0,0,0];  
     end
     
      save('xyzdb2.mat','real_minutia');
      
    end
end