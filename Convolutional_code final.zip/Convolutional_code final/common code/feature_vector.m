load('feature1.mat');
%feature1=feature3;
a=(1:3:21);
b=(3:3:21);
feature_vector1=[];
feature_vector2=[];
feature_vector21=[];
feature_vector22=[];
feature_vector11=[];
feature_vector2update=[];
for k=1:9
  for l=1:8
      s1=[];
      for i=1:length(a)
          s1=[s1;feature1{k,l}(1,a(i):a(i)+1)];
      end
    feature_vector1{k,l}=s1; 
    feature_vector11{k,l}=feature1{k,l}(b);
  end
end
for k=1:9
     for l=1:8
      Theta=[];
      Theta1=[];
      Theta2=[];
      file1=npermutek(1:7,3);
      for p=1:size(file1,1)
         Theta=[Theta;find_angle(feature_vector1{k,l}(file1(p,1),:),feature_vector1{k,l}(file1(p,2),:),feature_vector1{k,l}(file1(p,3),:))]; 
      end
       feature_vector2{k,l}=Theta';
      for p=1:size(file1,1)
         file1_1(p,:)=circshift(file1(p,:),1);
         file1_2(p,:)=circshift(file1(p,:),2);
      end
       for p=1:size(file1_1,1)
          Theta1=[Theta1;find_angle(feature_vector1{k,l}(file1_1(p,1),:),feature_vector1{k,l}(file1_1(p,2),:),feature_vector1{k,l}(file1_1(p,3),:))];
          Theta2=[Theta2;find_angle(feature_vector1{k,l}(file1_2(p,1),:),feature_vector1{k,l}(file1_2(p,2),:),feature_vector1{k,l}(file1_2(p,3),:))]; 

      end
       feature_vector21{k,l}=Theta1';
       feature_vector22{k,l}=Theta2';
     
      
      feature_vector2update{k,l}=sort(feature_vector11{k,l});
      for m=1:210
        feature_vector2update{k,l}(:,end+1)=feature_vector2{k,l}(:,m);
      end
      for m=1:210
        feature_vector2update{k,l}(:,end+1)=feature_vector21{k,l}(:,m);
      end
      for m=1:210
        feature_vector2update{k,l}(:,end+1)=feature_vector22{k,l}(:,m);
      end
    end
end
save([name 'result.mat'],'feature_vector2update');