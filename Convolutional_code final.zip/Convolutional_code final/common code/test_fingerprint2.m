dt1=load('FVC2004_DB3.mat');
name='FVC2004_DB3';
d=[];
ds=[];
d_core_result=[];
res=[];
d_core=[];
result_vec=[];
result_dt=dt1.real_minutia;
for p=1:9
    for k=1:8
        vect=[];
        vect2=[];
        dist=[];
        dist1=[];
        M=result_dt{p,k};      
        s=size(result_dt{p,k},1)-1;
        for i=1:s
            for j=1:s
                dist(i,j)=sqrt(sum((norm(result_dt{p,k}(i,1:2)-result_dt{p,k}(j,1:2)).^2)));
            end
        end
        dist1=dist;
        ds{p,k}=dist1;
        [x,in]=sort(dist1(end,:));
        d{p,k}=x;
       
       
        dt=result_dt{p,k}(in,:);
        d_res{p,k}=dt;
        
        
        vect=[vect,s];
        for j=1:s-1
            [out,idx]=sort(dist(s,:));
%              val=out(2);
             flag=1;
             h=2;
             while(flag)
                 index=idx(h);
                 true=ismember(index,vect);
                 if(true~=1)
                    vect=[vect;index];
                    flag=0;
                 else
                    h=h+1; 
                 end
             end
             s=index;
        end
        result_vec{p,k}=vect;
        d_core_result{p,k}=result_dt{p,k}(result_vec{p,k},:);
        d_core{p,k}=d_core_result{p,k}(((d_core_result{p,k}(:,3)~=5)& (d_core_result{p,k}(:,3)~=7)),:);
  %         
        
    end
%     figure(p);
%     plot(d_res{p,1}(:,1),d_res{p,1}(:,2),'ro');
%     hold on;
%     plot(d_res{p,2}(:,1),d_res{p,2}(:,2),'b*');
%     hold off;
end
save('d_core.mat','d_core');

