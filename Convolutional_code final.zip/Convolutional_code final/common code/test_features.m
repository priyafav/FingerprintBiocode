q1=load('d_core.mat');
feature1=[];
for i=1:9
    for j=1:8
      feature=[];
      for k=2:8
         feature=[feature,q1.d_core{i,j}(k,1:2)];
         feature=[feature,q1.d_core{i,j}(k,4)];
      end  
      feature1{i,j}=feature;
    end
end
save('feature1.mat','feature1');